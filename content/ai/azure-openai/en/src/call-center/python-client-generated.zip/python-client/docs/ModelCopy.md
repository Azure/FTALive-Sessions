# ModelCopy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**target_subscription_key** | **str** | The subscription key of the subscription that is the target of the copy operation. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


