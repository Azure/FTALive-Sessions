# BaseModelDeprecationDates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**adaptation_date_time** | **datetime** | The date when adaptation becomes deprecated. | [optional] 
**transcription_date_time** | **datetime** | The date when transcription becomes deprecated. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


